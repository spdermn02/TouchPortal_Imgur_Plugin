const fetch = require('node-fetch');
const fs = require('fs');
const FormData = require('form-data');
const TPClient = new (require('touchportal-api').Client)();

const pluginId = 'TouchPortal_Imgur';

// TODO - May need to allow setting to override
const clientId = '<imgur Client Id Here>';
const imgur = 'https://api.imgur.com/3/';

const uploadImage = (base64image) => {
    const form = new FormData();
    form.append('image',base64image);
    fetch(imgur+"/image",{ 
        method: 'POST', 
        body: form,
        headers: { 
            'Authorization': `Client-ID ${clientId}`  
        }
    })
    .then(res => res.json())
    .then(json => {
        logIt('DEBUG',JSON.stringify(json));
        const imageUrl = json.data.link;
        TPClient.stateUpdate('last_imgur_url',imageUrl);
    })
    .catch( reason => {
        logIt('ERROR',`Post to imur failed ${reason}`)
    })
}

const processImageUpload = (tpmessage) => {
    const filePath = tpmessage.data[0].value;
    fs.readFile(filePath, (err,data) => {
        if( err ) {
            logIt('ERROR',`attempting to read ${filePath} failed with: ${err}`);
            return;
        }
        const base64image = data.toString('base64');
        uploadImage(base64image);
    })
}

TPClient.on("Action", (message,hold) => {
    console.log(pluginId, ": DEBUG : ACTION ", JSON.stringify(message), "hold", hold);
    switch(message.actionId) {
        case 'imgur_upload_image':
            processImageUpload(message);
            break;
        default:
            logIt('WARN',`Unknown action of ${message.actionId}`);
    }
});

TPClient.on("Info", (data) => {
    //TP Is connected now
    logIt('DEBUG','We are connected, received Info message');
});

function logIt() {
    var curTime = new Date().toISOString();
    var message = [...arguments];
    var type = message.shift();
    console.log(curTime,":",pluginId,":"+type+":",message.join(" "));
}
    
TPClient.connect({ pluginId });